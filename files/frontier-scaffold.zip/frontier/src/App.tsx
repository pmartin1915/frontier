import { useRef, useEffect } from 'react';
import TravelLog from './ui/panels/TravelLog';
import AnimationPanel from './ui/panels/AnimationPanel';
import HUD from './ui/panels/HUD';
import MapPanel from './ui/panels/MapPanel';

/**
 * Root layout: 4-panel 2x2 grid per GDD §8.1.
 *
 * Left column:  Travel Log (full height)
 * Right column: Animation (top), HUD (middle), Map (bottom)
 *
 * Phase 0 deliverable: all four panels render, Phaser canvas in AnimationPanel.
 */
export default function App() {
  return (
    <div style={styles.container}>
      {/* Left: Travel Log (full height) */}
      <div style={styles.travelLog}>
        <TravelLog />
      </div>

      {/* Right: stacked panels */}
      <div style={styles.rightColumn}>
        <div style={styles.animation}>
          <AnimationPanel />
        </div>
        <div style={styles.hud}>
          <HUD />
        </div>
        <div style={styles.map}>
          <MapPanel />
        </div>
      </div>
    </div>
  );
}

/**
 * Inline styles for Phase 0. Will migrate to CSS/Tailwind once
 * the bridge is confirmed working.
 */
const styles: Record<string, React.CSSProperties> = {
  container: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    width: '100vw',
    height: '100vh',
    background: '#fdfbf7',
  },
  travelLog: {
    gridRow: '1 / -1',
    borderRight: '1px solid #e8dcc8',
    overflow: 'hidden',
  },
  rightColumn: {
    display: 'grid',
    gridTemplateRows: '2fr 1fr 1fr',
    overflow: 'hidden',
  },
  animation: {
    borderBottom: '1px solid #e8dcc8',
    background: '#1a1a1a',
  },
  hud: {
    borderBottom: '1px solid #e8dcc8',
    padding: '12px',
  },
  map: {
    padding: '12px',
  },
};
