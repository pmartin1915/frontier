import { useRef, useEffect, useState } from 'react';
import Phaser from 'phaser';
import { store } from '@/store';
import type { GameCommand } from '@/types/animation';

/**
 * Animation Panel — upper-right quadrant.
 * Embeds the Phaser canvas and manages the React-Phaser bridge.
 *
 * Phase 0 deliverable: Phaser canvas renders, bridge events fire.
 */
export default function AnimationPanel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const [bridgeStatus, setBridgeStatus] = useState<'initializing' | 'connected' | 'failed'>('initializing');

  useEffect(() => {
    if (!containerRef.current || gameRef.current) return;

    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      parent: containerRef.current,
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      backgroundColor: '#1a1a1a',
      pixelArt: true,
      scale: {
        mode: Phaser.Scale.RESIZE,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
      scene: [BootScene],
    };

    try {
      gameRef.current = new Phaser.Game(config);
      setBridgeStatus('connected');
    } catch (err) {
      console.error('Phaser initialization failed:', err);
      setBridgeStatus('failed');
    }

    // Phaser → React event bridge
    const onCampReady = () => {
      console.log('[Bridge] Phaser → React: camp-ready');
    };

    // Listen for custom events from Phaser
    if (gameRef.current) {
      gameRef.current.events.on('camp-ready', onCampReady);
    }

    return () => {
      if (gameRef.current) {
        gameRef.current.events.off('camp-ready', onCampReady);
        gameRef.current.destroy(true);
        gameRef.current = null;
      }
    };
  }, []);

  return (
    <div ref={containerRef} style={styles.container}>
      {bridgeStatus === 'failed' && (
        <div style={styles.error}>
          Phaser failed to initialize. Check console.
        </div>
      )}
    </div>
  );
}

/**
 * Boot Scene — Phase 0 minimal scene.
 * Demonstrates Zustand subscribe() bridge and command queue.
 */
class BootScene extends Phaser.Scene {
  private unsubscribe?: () => void;

  constructor() {
    super({ key: 'BootScene' });
  }

  create() {
    // Zustand subscribe() — Phaser peeks at store without React render
    this.unsubscribe = store.subscribe(
      (s) => s.world.biome,
      (biome) => {
        console.log(`[Bridge] Zustand → Phaser: biome changed to ${biome}`);
      },
    );

    // Placeholder text
    this.add
      .text(
        this.cameras.main.centerX,
        this.cameras.main.centerY,
        'FRONTIER\nPhaser Bridge Active',
        {
          fontSize: '16px',
          color: '#c4b08b',
          fontFamily: 'Georgia, serif',
          align: 'center',
        },
      )
      .setOrigin(0.5);

    // Emit bridge confirmation
    this.game.events.emit('camp-ready');
  }

  update() {
    // Read command queue from Zustand
    const commands = store.getState().commandQueue;
    if (commands.length > 0) {
      commands.forEach((cmd: GameCommand) => {
        console.log(`[Bridge] React → Phaser command:`, cmd);
        // Process commands here
      });
      store.getState().clearCommands();
    }
  }

  shutdown() {
    this.unsubscribe?.();
  }
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    width: '100%',
    height: '100%',
    position: 'relative',
  },
  error: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    color: '#c0392b',
    fontSize: '14px',
    fontFamily: 'monospace',
  },
};
