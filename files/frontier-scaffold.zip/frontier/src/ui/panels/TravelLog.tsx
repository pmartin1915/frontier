import { useStore } from '@/store';
import { selectPreviousEntry, selectCurrentVoice, selectDailyCyclePhase } from '@/store/selectors';

/**
 * Travel Log panel — left column, full height.
 * Displays the AI-generated narrative entries.
 * Per GDD §8.2: Crimson Text, near-black on cream, WCAG AAA.
 */
export default function TravelLog() {
  const entry = useStore(selectPreviousEntry);
  const voice = useStore(selectCurrentVoice);
  const phase = useStore(selectDailyCyclePhase);

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h2 style={styles.title}>Travel Log</h2>
        {voice && (
          <span style={styles.voiceBadge}>
            {voice.charAt(0).toUpperCase() + voice.slice(1)}
          </span>
        )}
      </header>
      <div style={styles.content}>
        {entry ? (
          <p style={styles.entry}>{entry}</p>
        ) : (
          <p style={styles.placeholder}>
            {phase === 'idle'
              ? 'The trail awaits. Begin a new day.'
              : 'Composing entry\u2026'}
          </p>
        )}
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    padding: '24px',
    fontFamily: "'Crimson Text', 'Lora', Georgia, serif",
    color: '#1a1a1a',
    background: '#fdfbf7',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
    borderBottom: '1px solid #e8dcc8',
    paddingBottom: '8px',
  },
  title: {
    fontSize: '18px',
    fontWeight: 600,
    color: '#5B3A29',
  },
  voiceBadge: {
    fontSize: '12px',
    color: '#6B6B6B',
    fontStyle: 'italic',
  },
  content: {
    flex: 1,
    overflowY: 'auto',
  },
  entry: {
    fontSize: '16px',
    lineHeight: '1.7',
  },
  placeholder: {
    fontSize: '16px',
    color: '#6B6B6B',
    fontStyle: 'italic',
  },
};
