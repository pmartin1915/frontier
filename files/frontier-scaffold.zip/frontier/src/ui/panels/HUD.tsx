import { useStore } from '@/store';
import {
  selectPlayerHealth,
  selectPlayerMorale,
  selectWater,
  selectFood,
  selectCoffee,
  selectAmmo,
  selectDaysElapsed,
  selectTotalMiles,
  selectHorseHealth,
  selectConsecutiveFallbacks,
} from '@/store/selectors';
import { CONSECUTIVE_FALLBACK_WARNING_THRESHOLD } from '@/types/narrative';

/**
 * HUD panel — middle-right.
 * Displays vital stats using atomic selectors.
 * Per GDD §8.2: Near-black on cream, high contrast.
 */
export default function HUD() {
  const health = useStore(selectPlayerHealth);
  const morale = useStore(selectPlayerMorale);
  const water = useStore(selectWater);
  const food = useStore(selectFood);
  const coffee = useStore(selectCoffee);
  const ammo = useStore(selectAmmo);
  const days = useStore(selectDaysElapsed);
  const miles = useStore(selectTotalMiles);
  const horseHealth = useStore(selectHorseHealth);
  const fallbacks = useStore(selectConsecutiveFallbacks);

  return (
    <div style={styles.container}>
      <div style={styles.row}>
        <Stat label="Day" value={days} />
        <Stat label="Miles" value={miles} />
        <Stat label="Health" value={health} warn={health < 40} />
        <Stat label="Morale" value={morale} warn={morale < 30} />
      </div>
      <div style={styles.row}>
        <Stat label="Water" value={water} warn={water < 10} />
        <Stat label="Food" value={food} warn={food < 10} />
        <Stat label="Coffee" value={coffee} warn={coffee === 0} />
        <Stat label="Ammo" value={ammo} />
      </div>
      <div style={styles.row}>
        <Stat label="Horse" value={horseHealth} warn={horseHealth < 40} />
      </div>
      {fallbacks >= CONSECUTIVE_FALLBACK_WARNING_THRESHOLD && (
        <div style={styles.connectionWarning}>
          Connection unstable
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, warn = false }: { label: string; value: number; warn?: boolean }) {
  return (
    <div style={styles.stat}>
      <span style={styles.label}>{label}</span>
      <span style={{ ...styles.value, color: warn ? '#a33' : '#1a1a1a' }}>{value}</span>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    fontFamily: "'Crimson Text', Georgia, serif",
    fontSize: '14px',
  },
  row: {
    display: 'flex',
    gap: '16px',
    flexWrap: 'wrap',
  },
  stat: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    minWidth: '48px',
  },
  label: {
    fontSize: '11px',
    color: '#6B6B6B',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.5px',
  },
  value: {
    fontSize: '18px',
    fontWeight: 600,
  },
  connectionWarning: {
    fontSize: '11px',
    color: '#8B6914',
    fontStyle: 'italic',
    textAlign: 'center' as const,
    marginTop: '4px',
  },
};
