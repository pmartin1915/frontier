import { useStore } from '@/store';
import { selectTotalMiles, selectWaypoint, selectCurrentAct } from '@/store/selectors';

/**
 * Map Panel — lower-right.
 * SVG trail map placeholder. Full implementation in Phase 2.
 */
export default function MapPanel() {
  const miles = useStore(selectTotalMiles);
  const waypoint = useStore(selectWaypoint);
  const act = useStore(selectCurrentAct);

  return (
    <div style={styles.container}>
      <div style={styles.label}>Trail Map</div>
      <div style={styles.info}>
        <span>{miles} mi</span>
        <span style={styles.separator}>&middot;</span>
        <span>{waypoint}</span>
        <span style={styles.separator}>&middot;</span>
        <span>{act.replace('act', 'Act ')}</span>
      </div>
      {/* SVG map will be rendered here in Phase 2 */}
      <div style={styles.placeholder}>
        <svg viewBox="0 0 400 200" style={{ width: '100%', height: '100%', opacity: 0.3 }}>
          <line x1="20" y1="160" x2="380" y2="40" stroke="#5B3A29" strokeWidth="2" strokeDasharray="8 4" />
          <circle cx="20" cy="160" r="5" fill="#5B3A29" />
          <circle cx="380" cy="40" r="5" fill="#5B3A29" />
          <text x="20" y="180" fontSize="10" fill="#6B6B6B" fontFamily="Georgia">Ft. Belknap</text>
          <text x="340" y="35" fontSize="10" fill="#6B6B6B" fontFamily="Georgia">Denver</text>
        </svg>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    fontFamily: "'Crimson Text', Georgia, serif",
  },
  label: {
    fontSize: '12px',
    color: '#6B6B6B',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.5px',
    marginBottom: '4px',
  },
  info: {
    fontSize: '13px',
    color: '#1a1a1a',
    marginBottom: '8px',
  },
  separator: {
    margin: '0 6px',
    color: '#c4b08b',
  },
  placeholder: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
