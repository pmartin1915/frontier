/**
 * Frontier — Zustand Store
 *
 * Single source of shared state between React and Phaser.
 * See CLAUDE.md for ownership rules.
 *
 * Phaser reads via store.subscribe() in scene create().
 * React reads via atomic selectors (see selectors.ts).
 * Only engine/daily-cycle.ts should call bulk state mutations.
 */

import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import type {
  GameState,
  WorldState,
  PlayerState,
  HorseState,
  Supplies,
  CampPet,
  JourneyState,
  MetaState,
  PartyState,
  NarrativeState,
  Act,
  Biome,
  Pace,
  TimeOfDay,
  Weather,
  DiscretionaryAction,
  MoraleState,
} from '@/types/game-state';
import type { GameCommand } from '@/types/animation';
import type { NarratorResponse } from '@/types/narrative';

// ============================================================
// STORE INTERFACE
// ============================================================

export interface FrontierStore extends GameState {
  // --- UI State (not persisted) ---
  /** Whether the game is in a loading state */
  loading: boolean;
  /** Current phase of the daily cycle */
  dailyCyclePhase: 'briefing' | 'decisions' | 'travel' | 'event' | 'evening' | 'idle';
  /** Active encounter (if any) */
  activeEncounterId: string | null;
  /** Consecutive API fallbacks (for HUD warning) */
  consecutiveFallbacks: number;

  // --- Phaser Bridge ---
  /** Command queue: React → Phaser */
  commandQueue: GameCommand[];
  pushCommand: (cmd: GameCommand) => void;
  clearCommands: () => void;

  // --- Actions: Game Flow ---
  /** Initialize a new game with starting state */
  initializeGame: (playerName: string, horseName: string) => void;
  /** Advance to the next daily cycle phase */
  advancePhase: () => void;
  /** Set player decisions for the day */
  setDailyDecisions: (pace: Pace, action: DiscretionaryAction) => void;

  // --- Actions: State Updates (called by engine) ---
  /** Bulk update after Game Logic resolves a day */
  applyDayResults: (results: DayResults) => void;
  /** Apply Narrator response to narrative state */
  applyNarratorResponse: (response: NarratorResponse) => void;
  /** Update a specific supply value */
  updateSupply: (key: keyof Supplies, delta: number) => void;

  // --- Actions: Persistence ---
  /** Serialize active state for IndexedDB save */
  serializeActiveState: () => string;
  /** Load state from IndexedDB or JSON import */
  loadState: (state: GameState) => void;
}

/**
 * Results from the Game Logic layer for a single day.
 * Applied to the store in one atomic update.
 */
export interface DayResults {
  world: Partial<WorldState>;
  player: Partial<PlayerState>;
  horse: Partial<HorseState>;
  supplies: Partial<Supplies>;
  party: Partial<PartyState>;
  journey: Partial<JourneyState>;
  campPet?: Partial<CampPet>;
}

// ============================================================
// INITIAL STATE
// ============================================================

const INITIAL_WORLD: WorldState = {
  date: '1866-06-06',
  timeOfDay: TimeOfDay.Dawn,
  weather: Weather.Clear,
  biome: Biome.CrossTimbers,
  terrain: 'prairie' as any,
  distanceToWaypoint: 130,
  totalMiles: 0,
  currentAct: Act.I,
  windSpeed: 15,
  temperature: 78,
};

const INITIAL_PLAYER: PlayerState = {
  name: 'Martin',
  health: 100,
  conditions: [],
  fatigue: 0,
  morale: 65,
  skills: { survival: 40, navigation: 30, combat: 35, barter: 25 },
  equipment: [
    { slot: 'saddle' as any, durability: 100 },
    { slot: 'boots' as any, durability: 100 },
    { slot: 'rifle' as any, durability: 100 },
    { slot: 'canteen' as any, durability: 100 },
    { slot: 'bedroll' as any, durability: 100 },
  ],
};

const INITIAL_HORSE: HorseState = {
  name: 'Horse',
  health: 100,
  fatigue: 0,
  lameness: false,
  thirst: 0,
  hunger: 0,
  tackCondition: 100,
};

const INITIAL_SUPPLIES: Supplies = {
  water: 40,
  food: 35,
  coffee: 10,
  medical: 5,
  repair: 5,
  ammo: 20,
  tradeGoods: 15,
  funds: 50,
};

// ============================================================
// STORE CREATION
// ============================================================

export const useStore = create<FrontierStore>()(
  subscribeWithSelector((set, get) => ({
    // --- Initial Game State ---
    world: INITIAL_WORLD,
    player: INITIAL_PLAYER,
    horse: INITIAL_HORSE,
    party: { companions: [], maxCompanions: 4 },
    supplies: INITIAL_SUPPLIES,
    campPet: { adopted: false, name: null, dayAdopted: null, lost: false, dayLost: null },
    narrative: {
      structuredLedger: [],
      chapterSummaries: [],
      previousEntry: '',
      activeThreads: [],
      currentVoice: 'adams' as any,
    },
    journey: {
      currentAct: Act.I,
      waypoint: 'Middle Concho',
      routeChoices: [],
      daysElapsed: 0,
      failForwardsUsed: 0,
      fortSumnerDebt: false,
      nightTravel: false,
      pace: Pace.Normal,
      discretionaryAction: DiscretionaryAction.None,
    },
    meta: {
      saveSlot: 0,
      timestamp: new Date().toISOString(),
      hash: '',
      version: 1,
      playtimeMs: 0,
    },

    // --- UI State ---
    loading: false,
    dailyCyclePhase: 'idle',
    activeEncounterId: null,
    consecutiveFallbacks: 0,

    // --- Phaser Bridge ---
    commandQueue: [],
    pushCommand: (cmd) => set((s) => ({ commandQueue: [...s.commandQueue, cmd] })),
    clearCommands: () => set({ commandQueue: [] }),

    // --- Game Flow ---
    initializeGame: (playerName, horseName) => set({
      player: { ...INITIAL_PLAYER, name: playerName },
      horse: { ...INITIAL_HORSE, name: horseName },
      dailyCyclePhase: 'briefing',
    }),

    advancePhase: () => set((s) => {
      const phases: FrontierStore['dailyCyclePhase'][] = [
        'briefing', 'decisions', 'travel', 'event', 'evening', 'idle',
      ];
      const idx = phases.indexOf(s.dailyCyclePhase);
      const next = phases[(idx + 1) % phases.length];
      return { dailyCyclePhase: next };
    }),

    setDailyDecisions: (pace, action) => set((s) => ({
      journey: { ...s.journey, pace, discretionaryAction: action },
    })),

    // --- State Updates ---
    applyDayResults: (results) => set((s) => ({
      world: { ...s.world, ...results.world },
      player: { ...s.player, ...results.player },
      horse: { ...s.horse, ...results.horse },
      supplies: { ...s.supplies, ...results.supplies },
      party: { ...s.party, ...results.party },
      journey: { ...s.journey, ...results.journey },
      campPet: results.campPet ? { ...s.campPet, ...results.campPet } : s.campPet,
    })),

    applyNarratorResponse: (response) => set((s) => ({
      narrative: {
        ...s.narrative,
        previousEntry: response.text,
        currentVoice: response.voice,
      },
      consecutiveFallbacks: response.fallback
        ? s.consecutiveFallbacks + 1
        : 0,
    })),

    updateSupply: (key, delta) => set((s) => ({
      supplies: {
        ...s.supplies,
        [key]: Math.max(0, s.supplies[key] + delta),
      },
    })),

    // --- Persistence ---
    serializeActiveState: () => {
      const s = get();
      const active: GameState = {
        world: s.world,
        player: s.player,
        horse: s.horse,
        party: s.party,
        supplies: s.supplies,
        campPet: s.campPet,
        narrative: s.narrative,
        journey: s.journey,
        meta: { ...s.meta, timestamp: new Date().toISOString() },
      };
      return JSON.stringify(active);
    },

    loadState: (state) => set({
      ...state,
      loading: false,
      dailyCyclePhase: 'briefing',
      activeEncounterId: null,
      consecutiveFallbacks: 0,
      commandQueue: [],
    }),
  }))
);

/**
 * Direct store access for Phaser scenes.
 * Use this in Phaser scene create() with subscribe():
 *
 * ```ts
 * import { store } from '@/store';
 * store.subscribe(
 *   (s) => s.world.biome,
 *   (biome) => this.updateBiome(biome)
 * );
 * ```
 */
export const store = useStore;
