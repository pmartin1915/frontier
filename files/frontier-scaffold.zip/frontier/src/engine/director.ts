/**
 * Frontier — Layer 2: Director
 *
 * Rule-based switchboard. No AI calls. Pure deterministic logic.
 *
 * Receives EventRecord from Game Logic.
 * Selects author voice via the Voice Switchboard.
 * Assembles the prompt for the Narrator.
 * Manages Narrative Ledger updates.
 */

import type { EventRecord, VoiceDirective, NarratorPrompt } from '@/types/narrative';
import { VOICE_SWITCHBOARD, VOICE_CONSTRAINTS } from '@/types/narrative';
import type { GameState } from '@/types/game-state';

/**
 * Select the author voice based on the day's dominant event.
 */
export function selectVoice(eventRecord: EventRecord): VoiceDirective {
  const entry = VOICE_SWITCHBOARD.find((e) => e.eventType === eventRecord.dominantEvent);
  const primary = entry?.primary ?? 'adams';
  const secondary = entry?.secondary ?? null;

  return {
    primaryVoice: primary,
    secondaryVoice: secondary,
    constraints: VOICE_CONSTRAINTS[primary],
    emotionalArc: '', // TODO: derive from Ledger
    threadReferences: [], // TODO: derive from active threads
    characterBibles: [], // TODO: include for active companions
    foreshadowingHints: [], // TODO: derive from pending consequences
  };
}

/**
 * Assemble the complete Narrator prompt.
 */
export function assemblePrompt(
  _directive: VoiceDirective,
  _eventRecord: EventRecord,
  _state: GameState,
): NarratorPrompt {
  // TODO: Phase 1-2 implementation
  // 1. Build system message (author persona + anachronism firewall)
  // 2. Serialize Ledger context (EARLY in prompt)
  // 3. Include Character Bibles for active companions
  // 4. Include previous day's entry
  // 5. Serialize EventRecord as JSON
  // 6. Serialize game state snapshot
  // 7. Serialize voice directive

  throw new Error('Not implemented — Phase 1');
}

/**
 * Check if a Ledger Entry should be generated (every 5 days).
 */
export function shouldGenerateLedgerEntry(daysElapsed: number): boolean {
  return daysElapsed > 0 && daysElapsed % 5 === 0;
}
