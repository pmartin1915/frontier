/**
 * Frontier — Animation & Sprite System Interfaces
 *
 * Per GDD §7.4: Strict animation state machine with validated transitions,
 * directional flip utility, walk cycle locking, and accessory layer system.
 */

import { Biome, TimeOfDay } from './game-state';
import { CompanionId } from './companions';

// ============================================================
// ANIMATION STATE MACHINE
// ============================================================

export enum AnimationState {
  Idle = 'idle',
  Walk = 'walk',
  Run = 'run',
  Mount = 'mount',
  Ride = 'ride',
  Interact = 'interact',
  Injured = 'injured',
  Death = 'death',
}

/**
 * Sprite sheet layout: each state maps to a row in the sheet.
 */
export interface SpriteSheetConfig {
  key: string;
  path: string;
  frameWidth: number;
  frameHeight: number;
  rows: Record<AnimationState, SpriteRowConfig>;
}

export interface SpriteRowConfig {
  row: number;
  frameCount: number;
  /** Frames per second at Normal pace */
  baseFrameRate: number;
  /** Whether this animation loops */
  loop: boolean;
}

/**
 * Valid state transitions. The FSM rejects any transition not in this map.
 * Key = current state, Value = set of valid next states.
 */
export const VALID_TRANSITIONS: Record<AnimationState, Set<AnimationState>> = {
  [AnimationState.Idle]: new Set([AnimationState.Walk, AnimationState.Mount, AnimationState.Interact]),
  [AnimationState.Walk]: new Set([AnimationState.Idle, AnimationState.Run, AnimationState.Mount]),
  [AnimationState.Run]: new Set([AnimationState.Walk, AnimationState.Idle]),
  [AnimationState.Mount]: new Set([AnimationState.Idle, AnimationState.Ride]),
  [AnimationState.Ride]: new Set([AnimationState.Idle]),
  [AnimationState.Interact]: new Set([AnimationState.Idle]),
  [AnimationState.Injured]: new Set([AnimationState.Idle, AnimationState.Death]),
  [AnimationState.Death]: new Set([]),
};

/**
 * Validates a state transition. Returns true if the transition is legal.
 */
export function isValidTransition(from: AnimationState, to: AnimationState): boolean {
  return VALID_TRANSITIONS[from].has(to);
}

// ============================================================
// DIRECTIONAL FLIP
// ============================================================

export enum FacingDirection {
  Right = 'right',
  Left = 'left',
}

/**
 * Asymmetric elements that need separate overlay sprites when flipped.
 * These are NOT flipped with flipX—they use dedicated left-facing overlays.
 */
export interface FlipExemptElement {
  key: string;
  description: string;
  /** Overlay sprite key for left-facing version */
  leftSpriteKey: string;
}

// ============================================================
// ACCESSORY LAYER SYSTEM
// ============================================================

/**
 * An accessory overlay that tracks a parent sprite's position and frame.
 * Rendered on a transparent background above the character sprite.
 */
export interface AccessoryConfig {
  id: string;
  /** Which character this accessory belongs to */
  owner: 'player' | CompanionId;
  /** Sprite sheet key for this accessory */
  spriteKey: string;
  /** Whether this accessory is currently visible */
  visible: boolean;
  /** Offset from parent sprite origin (pixels) */
  offsetX: number;
  offsetY: number;
  /** Whether this accessory is flip-exempt (needs left-facing variant) */
  flipExempt: boolean;
  /** Conditions that toggle this accessory */
  toggleConditions?: AccessoryToggle[];
}

export interface AccessoryToggle {
  type: 'weather' | 'health' | 'event' | 'custom';
  /** Condition that makes the accessory visible */
  showWhen: string;
  /** Condition that hides the accessory */
  hideWhen: string;
}

/**
 * Pre-defined companion accessories per GDD §7.4.
 */
export const COMPANION_ACCESSORIES: Record<CompanionId, AccessoryConfig[]> = {
  [CompanionId.EliasCoe]: [
    {
      id: 'coe-kepi', owner: CompanionId.EliasCoe,
      spriteKey: 'acc_coe_kepi', visible: true,
      offsetX: 0, offsetY: -4, flipExempt: false,
      toggleConditions: [
        { type: 'weather', showWhen: 'default', hideWhen: 'storm' },
      ],
    },
  ],
  [CompanionId.LuisaVega]: [
    {
      id: 'vega-serape', owner: CompanionId.LuisaVega,
      spriteKey: 'acc_vega_serape', visible: true,
      offsetX: 0, offsetY: 0, flipExempt: false,
    },
    {
      id: 'vega-poncho', owner: CompanionId.LuisaVega,
      spriteKey: 'acc_vega_poncho', visible: false,
      offsetX: 0, offsetY: 0, flipExempt: false,
      toggleConditions: [
        { type: 'weather', showWhen: 'rain', hideWhen: 'clear' },
      ],
    },
  ],
  [CompanionId.TomBlanchard]: [
    {
      id: 'blanchard-bandana', owner: CompanionId.TomBlanchard,
      spriteKey: 'acc_blanchard_bandana', visible: true,
      offsetX: 0, offsetY: -2, flipExempt: false,
      toggleConditions: [
        { type: 'event', showWhen: 'default', hideWhen: 'windstorm_loss' },
      ],
    },
  ],
};

// ============================================================
// TIME-OF-DAY PALETTES (per GDD §7.2)
// ============================================================

export interface PaletteConfig {
  timeOfDay: TimeOfDay;
  /** CSS-compatible color values for the palette */
  sky: string;
  ambient: string;
  shadow: string;
  description: string;
}

export const TIME_PALETTES: Record<TimeOfDay, PaletteConfig> = {
  [TimeOfDay.Dawn]: { timeOfDay: TimeOfDay.Dawn, sky: '#4a6fa5', ambient: '#d4b896', shadow: '#2a3f5f', description: 'Cool blues to pale gold, stars fading' },
  [TimeOfDay.Morning]: { timeOfDay: TimeOfDay.Morning, sky: '#87CEEB', ambient: '#f5deb3', shadow: '#4a4a2a', description: 'Clear warm yellows, sharp shadows' },
  [TimeOfDay.Midday]: { timeOfDay: TimeOfDay.Midday, sky: '#e8e4d0', ambient: '#ffffff', shadow: '#c8c4b0', description: 'Harsh whites, bleached, heat haze' },
  [TimeOfDay.Afternoon]: { timeOfDay: TimeOfDay.Afternoon, sky: '#d4a843', ambient: '#e8a020', shadow: '#6b4e1a', description: 'Amber to orange, long shadows' },
  [TimeOfDay.Sunset]: { timeOfDay: TimeOfDay.Sunset, sky: '#c0392b', ambient: '#e74c3c', shadow: '#4a1a2e', description: 'Deep orange/red/purple, silhouettes' },
  [TimeOfDay.Night]: { timeOfDay: TimeOfDay.Night, sky: '#1a1a3e', ambient: '#2a2a5e', shadow: '#0a0a1e', description: 'Deep blues, silver, campfire glow' },
};

// ============================================================
// PHASER COMMAND QUEUE
// ============================================================

export type GameCommand =
  | { type: 'changeScene'; scene: 'trail' | 'camp' | 'boot' }
  | { type: 'updateBiome'; biome: Biome }
  | { type: 'updateTimeOfDay'; timeOfDay: TimeOfDay }
  | { type: 'playAnimation'; target: string; state: AnimationState }
  | { type: 'toggleAccessory'; accessoryId: string; visible: boolean }
  | { type: 'setFacing'; target: string; direction: FacingDirection }
  | { type: 'triggerWeatherEffect'; weather: string }
  | { type: 'showCampfire'; show: boolean }
  | { type: 'setCampPetVisible'; visible: boolean };
