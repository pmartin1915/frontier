/**
 * Frontier — Narrator API Edge Function
 *
 * Vercel serverless function that proxies requests to the Anthropic API.
 * Per GDD §9.4: IP-based rate limiting + integrityHash session validation.
 *
 * Route: POST /api/narrator
 *
 * NOTE: This is a stub. Full implementation requires:
 * - Vercel KV for rate limit counters
 * - Session registry for integrityHash validation
 * - Proper error handling and logging
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';

// Rate limit tiers per GDD §9.4
const RATE_LIMITS = {
  normal: { requests: 10, windowSeconds: 60 },
  burst: { requests: 20, windowSeconds: 60, softLockMinutes: 5 },
  sustained: { requests: 100, windowSeconds: 3600, blockHours: 24 },
} as const;

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-5-20250929';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // CORS enforcement
  const origin = req.headers.origin;
  const allowedDomain = process.env.VITE_APP_DOMAIN || 'http://localhost:3000';
  if (origin && origin !== allowedDomain) {
    return res.status(403).json({ error: 'Origin not allowed' });
  }

  // Extract integrityHash from request
  const { integrityHash, prompt } = req.body || {};
  if (!integrityHash || !prompt) {
    return res.status(400).json({ error: 'Missing integrityHash or prompt' });
  }

  // TODO: Validate integrityHash against session registry (Vercel KV)
  // TODO: Check IP rate limits (Vercel KV)
  // TODO: Validate state delta plausibility

  try {
    const response = await fetch(ANTHROPIC_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 500,
        system: prompt.systemMessage,
        messages: [
          {
            role: 'user',
            content: [
              prompt.ledgerContext,
              prompt.characterBibles,
              prompt.previousEntry,
              prompt.eventRecord,
              prompt.gameStateSnapshot,
              prompt.voiceDirective,
            ].join('\n\n'),
          },
        ],
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('Anthropic API error:', error);
      return res.status(502).json({ error: 'Narrator API error' });
    }

    const data = await response.json();
    return res.status(200).json(data);
  } catch (err) {
    console.error('Narrator proxy error:', err);
    return res.status(500).json({ error: 'Internal error' });
  }
}
